package com.example.miniproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
